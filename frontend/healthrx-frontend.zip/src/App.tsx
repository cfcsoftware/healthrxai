import AppRouter from './routes/AppRouter'
import './index.css'
function App() {
  return <AppRouter />
}

export default App
