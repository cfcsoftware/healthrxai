// const Footer = () => (
//     <footer className="bg-gray-100 text-center text-sm text-gray-500 py-4 mt-auto">
//       &copy; {new Date().getFullYear()} HealthRx AI. All rights reserved.
//     </footer>
//   );
  
//   export default Footer;
  